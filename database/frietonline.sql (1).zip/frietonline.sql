-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Machine: localhost
-- Genereertijd: 12 Aug 2016 om 18:50
-- Serverversie: 5.1.37
-- PHP-Versie: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `frietonline`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `adminsettings`
--

CREATE TABLE IF NOT EXISTS `adminsettings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `clientLevel` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Gegevens worden uitgevoerd voor tabel `adminsettings`
--

INSERT INTO `adminsettings` (`id`, `clientLevel`) VALUES
(1, 1);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `bezoeker`
--

CREATE TABLE IF NOT EXISTS `bezoeker` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(50) NOT NULL,
  `bezoekdatum` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Gegevens worden uitgevoerd voor tabel `bezoeker`
--

INSERT INTO `bezoeker` (`id`, `ip`, `bezoekdatum`) VALUES
(1, '::1', '2016-05-20 02:53:06'),
(2, '::1', '2016-08-07 14:59:32'),
(3, '::1', '2016-08-08 15:59:54'),
(4, '::1', '2016-08-10 19:35:29'),
(5, '::1', '2016-08-11 01:43:31'),
(6, '::1', '2016-08-12 01:19:43'),
(7, '::1', '2016-08-12 18:10:19');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `bezoekerhit`
--

CREATE TABLE IF NOT EXISTS `bezoekerhit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(50) NOT NULL,
  `bezoekdatum` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=135 ;

--
-- Gegevens worden uitgevoerd voor tabel `bezoekerhit`
--

INSERT INTO `bezoekerhit` (`id`, `ip`, `bezoekdatum`) VALUES
(1, '::1', '2016-05-20 02:53:06'),
(2, '::1', '2016-08-07 14:59:32'),
(3, '::1', '2016-08-08 15:59:54'),
(4, '::1', '2016-08-10 19:35:29'),
(5, '::1', '2016-08-10 20:19:19'),
(6, '::1', '2016-08-10 20:34:59'),
(7, '::1', '2016-08-10 20:37:55'),
(8, '::1', '2016-08-10 20:38:57'),
(9, '::1', '2016-08-10 20:40:12'),
(10, '::1', '2016-08-10 20:41:30'),
(11, '::1', '2016-08-10 20:41:37'),
(12, '::1', '2016-08-10 20:41:38'),
(13, '::1', '2016-08-10 20:41:38'),
(14, '::1', '2016-08-10 20:41:39'),
(15, '::1', '2016-08-10 20:41:39'),
(16, '::1', '2016-08-10 20:42:51'),
(17, '::1', '2016-08-10 20:42:52'),
(18, '::1', '2016-08-10 20:43:43'),
(19, '::1', '2016-08-10 20:47:08'),
(20, '::1', '2016-08-10 20:47:13'),
(21, '::1', '2016-08-10 20:50:12'),
(22, '::1', '2016-08-10 20:50:25'),
(23, '::1', '2016-08-10 20:52:02'),
(24, '::1', '2016-08-10 20:53:34'),
(25, '::1', '2016-08-10 20:57:01'),
(26, '::1', '2016-08-10 20:57:48'),
(27, '::1', '2016-08-10 20:59:03'),
(28, '::1', '2016-08-10 20:59:56'),
(29, '::1', '2016-08-10 21:00:09'),
(30, '::1', '2016-08-10 21:00:32'),
(31, '::1', '2016-08-10 21:02:10'),
(32, '::1', '2016-08-10 21:02:13'),
(33, '::1', '2016-08-10 21:02:35'),
(34, '::1', '2016-08-10 21:04:10'),
(35, '::1', '2016-08-10 21:06:51'),
(36, '::1', '2016-08-10 21:07:10'),
(37, '::1', '2016-08-10 21:07:35'),
(38, '::1', '2016-08-11 01:43:31'),
(39, '::1', '2016-08-11 01:45:15'),
(40, '::1', '2016-08-11 01:46:35'),
(41, '::1', '2016-08-11 01:47:12'),
(42, '::1', '2016-08-11 01:47:59'),
(43, '::1', '2016-08-11 01:52:08'),
(44, '::1', '2016-08-11 01:52:22'),
(45, '::1', '2016-08-11 01:52:39'),
(46, '::1', '2016-08-11 01:53:04'),
(47, '::1', '2016-08-11 01:55:17'),
(48, '::1', '2016-08-11 01:55:24'),
(49, '::1', '2016-08-11 02:21:42'),
(50, '::1', '2016-08-11 02:22:09'),
(51, '::1', '2016-08-11 02:22:52'),
(52, '::1', '2016-08-11 02:23:44'),
(53, '::1', '2016-08-11 02:24:11'),
(54, '::1', '2016-08-11 02:27:48'),
(55, '::1', '2016-08-11 02:29:06'),
(56, '::1', '2016-08-11 02:32:35'),
(57, '::1', '2016-08-11 02:32:42'),
(58, '::1', '2016-08-11 02:32:49'),
(59, '::1', '2016-08-11 02:32:56'),
(60, '::1', '2016-08-11 02:33:16'),
(61, '::1', '2016-08-11 02:33:27'),
(62, '::1', '2016-08-11 02:33:34'),
(63, '::1', '2016-08-11 02:33:45'),
(64, '::1', '2016-08-11 02:34:06'),
(65, '::1', '2016-08-11 02:34:17'),
(66, '::1', '2016-08-11 02:34:34'),
(67, '::1', '2016-08-11 02:34:43'),
(68, '::1', '2016-08-11 02:35:07'),
(69, '::1', '2016-08-11 02:35:40'),
(70, '::1', '2016-08-11 02:37:33'),
(71, '::1', '2016-08-11 02:46:44'),
(72, '::1', '2016-08-11 02:48:02'),
(73, '::1', '2016-08-11 02:48:41'),
(74, '::1', '2016-08-11 02:49:06'),
(75, '::1', '2016-08-11 02:50:39'),
(76, '::1', '2016-08-11 02:50:50'),
(77, '::1', '2016-08-11 02:52:13'),
(78, '::1', '2016-08-12 01:19:43'),
(79, '::1', '2016-08-12 01:20:03'),
(80, '::1', '2016-08-12 01:27:21'),
(81, '::1', '2016-08-12 02:27:33'),
(82, '::1', '2016-08-12 02:27:58'),
(83, '::1', '2016-08-12 02:29:07'),
(84, '::1', '2016-08-12 02:30:50'),
(85, '::1', '2016-08-12 02:30:57'),
(86, '::1', '2016-08-12 02:35:40'),
(87, '::1', '2016-08-12 02:36:55'),
(88, '::1', '2016-08-12 02:38:55'),
(89, '::1', '2016-08-12 02:39:06'),
(90, '::1', '2016-08-12 02:39:23'),
(91, '::1', '2016-08-12 03:30:51'),
(92, '::1', '2016-08-12 03:31:32'),
(93, '::1', '2016-08-12 03:33:56'),
(94, '::1', '2016-08-12 03:34:32'),
(95, '::1', '2016-08-12 03:34:48'),
(96, '::1', '2016-08-12 04:52:07'),
(97, '::1', '2016-08-12 04:56:31'),
(98, '::1', '2016-08-12 04:56:45'),
(99, '::1', '2016-08-12 04:57:49'),
(100, '::1', '2016-08-12 04:58:31'),
(101, '::1', '2016-08-12 04:59:11'),
(102, '::1', '2016-08-12 05:04:22'),
(103, '::1', '2016-08-12 05:09:41'),
(104, '::1', '2016-08-12 05:10:21'),
(105, '::1', '2016-08-12 05:13:01'),
(106, '::1', '2016-08-12 05:13:56'),
(107, '::1', '2016-08-12 05:14:06'),
(108, '::1', '2016-08-12 05:14:31'),
(109, '::1', '2016-08-12 05:14:38'),
(110, '::1', '2016-08-12 05:17:26'),
(111, '::1', '2016-08-12 05:37:12'),
(112, '::1', '2016-08-12 05:37:19'),
(113, '::1', '2016-08-12 05:37:32'),
(114, '::1', '2016-08-12 05:39:59'),
(115, '::1', '2016-08-12 05:40:15'),
(116, '::1', '2016-08-12 05:41:06'),
(117, '::1', '2016-08-12 05:41:15'),
(118, '::1', '2016-08-12 05:41:37'),
(119, '::1', '2016-08-12 05:42:18'),
(120, '::1', '2016-08-12 05:42:44'),
(121, '::1', '2016-08-12 05:45:44'),
(122, '::1', '2016-08-12 05:48:50'),
(123, '::1', '2016-08-12 18:10:19'),
(124, '::1', '2016-08-12 18:11:21'),
(125, '::1', '2016-08-12 18:12:43'),
(126, '::1', '2016-08-12 18:12:47'),
(127, '::1', '2016-08-12 18:14:10'),
(128, '::1', '2016-08-12 18:15:25'),
(129, '::1', '2016-08-12 18:17:33'),
(130, '::1', '2016-08-12 18:18:02'),
(131, '::1', '2016-08-12 18:24:07'),
(132, '::1', '2016-08-12 19:03:43'),
(133, '::1', '2016-08-12 19:06:32'),
(134, '::1', '2016-08-12 19:06:46');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `categorie`
--

CREATE TABLE IF NOT EXISTS `categorie` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `naam` varchar(50) NOT NULL,
  `hoofdcategorieId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `HoofdcategorieId` (`hoofdcategorieId`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Gegevens worden uitgevoerd voor tabel `categorie`
--

INSERT INTO `categorie` (`id`, `naam`, `hoofdcategorieId`) VALUES
(1, 'Broodjes', NULL),
(2, 'Snacks', NULL),
(3, 'Frieten', NULL),
(4, 'Dranken', NULL),
(5, 'Salades', NULL),
(6, 'Sauzen', NULL);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `id` int(11) NOT NULL,
  `gebruikersnaam` varchar(40) NOT NULL,
  `wachtwoord` varchar(30) NOT NULL,
  `adminlvl` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden uitgevoerd voor tabel `login`
--

INSERT INTO `login` (`id`, `gebruikersnaam`, `wachtwoord`, `adminlvl`) VALUES
(0, 'vinken', 'vinken', 1);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `menuitem`
--

CREATE TABLE IF NOT EXISTS `menuitem` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `naam` varchar(250) NOT NULL,
  `omschrijving` text NOT NULL,
  `fotoPad` varchar(250) NOT NULL,
  `prijs` double NOT NULL,
  `categorieId` int(11) NOT NULL,
  `vlees` tinyint(4) NOT NULL DEFAULT '0',
  `vis` tinyint(4) NOT NULL DEFAULT '0',
  `pikantheid` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `categorieId` (`categorieId`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Gegevens worden uitgevoerd voor tabel `menuitem`
--

INSERT INTO `menuitem` (`id`, `naam`, `omschrijving`, `fotoPad`, `prijs`, `categorieId`, `vlees`, `vis`, `pikantheid`) VALUES
(1, 'Broodje gezond', 'Broodje met kaas, hesp, aardappelsla, tomaat, ei en sla.', '', 3, 1, 0, 0, 3),
(2, 'Broodje boulet', 'Broodje met sla, ei, tomaat, boulet en cocktailsaus.', '', 3.5, 1, 1, 0, 0),
(3, 'Kleine friet', 'Kleine zak friet.', '', 1.8, 3, 0, 0, 0),
(4, 'Gewone friet', 'Gewone zak friet.', '', 2, 3, 0, 1, 0),
(5, 'Grote friet', 'Grote zak friet.', '', 2.2, 3, 0, 0, 0),
(6, 'Familie friet', 'Een zak friet voor de familie (2-3 personen).', '', 3.5, 3, 0, 0, 0),
(7, 'Frikandel', 'Frikandel van mora.', '', 2.3, 2, 1, 0, 0),
(8, 'Boulet', 'Ronde boulet gebakken.', '', 2.3, 2, 1, 0, 0),
(9, 'Playboy', 'Pikante playboy met look.', '', 2.5, 2, 1, 0, 2),
(10, 'Cola (33 cl.)', 'Blikje Cola van 33 cl.', '', 1.8, 4, 0, 0, 0),
(11, 'Fanta (33 cl.)', 'Blikje Fanta van 33 cl.', '', 1.8, 4, 0, 0, 0),
(12, 'Sprite (33 cl.)', 'Blikje Sprite van 33 cl.', '', 1.8, 4, 0, 0, 0);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `openingsuren`
--

CREATE TABLE IF NOT EXISTS `openingsuren` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dag` varchar(50) NOT NULL,
  `vanUur` int(11) NOT NULL,
  `vanMinuut` int(11) NOT NULL,
  `totUur` int(11) NOT NULL,
  `totMinuut` int(11) NOT NULL,
  `dow` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Gegevens worden uitgevoerd voor tabel `openingsuren`
--

INSERT INTO `openingsuren` (`id`, `dag`, `vanUur`, `vanMinuut`, `totUur`, `totMinuut`, `dow`) VALUES
(1, 'Maandag', 9, 0, 18, 0, 1),
(2, 'Dinsdag', 9, 0, 18, 0, 2),
(3, 'Woensdag', 9, 0, 18, 0, 3),
(4, 'Donderdag', 9, 0, 18, 0, 4),
(5, 'Vrijdag', 9, 0, 17, 0, 5),
(6, 'Zaterdag', 10, 0, 16, 0, 6),
(7, 'Zondag', 0, 0, 0, 0, 0),
(8, 'Feestdagen', 0, 0, 0, 0, 7);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `tekst`
--

CREATE TABLE IF NOT EXISTS `tekst` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `naam` varchar(150) NOT NULL,
  `pagina` varchar(150) NOT NULL,
  `tekst` text NOT NULL,
  `tekstgrootte` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Gegevens worden uitgevoerd voor tabel `tekst`
--

INSERT INTO `tekst` (`id`, `naam`, `pagina`, `tekst`, `tekstgrootte`) VALUES
(1, 'Home tekst', 'home.php', '<ul>\r\n<li>Welkom bij frietonline!<li>\r\n<li>Bekijk ons aanbod en bestel nu!</li>\r\n<ul>', 195),
(2, 'Over ons tekst', 'overons.php', '<ul>\r\n<li>Ricardo is stoer, Jeroen is ook stoer. What would <strong>you</strong> want more!\r\n </ul>', 100),
(3, 'Contact openingsuren', 'info.php', '<ul>\r\n <li>Maandag - Zaterdag: 10:30 - 17:30</li>\r\n<li>Zondag: gesloten</li>\r\n </ul>', 100),
(4, 'Timer tekst', 'timer.php', 'Beste klant wij zijn momenteel bezig om onze website voor u te verbeteren. Tijd tot de website terug beschikbaar is:', 175);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
