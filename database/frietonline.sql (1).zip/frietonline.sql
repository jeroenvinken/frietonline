-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Machine: localhost
-- Genereertijd: 20 Mei 2016 om 00:56
-- Serverversie: 5.1.37
-- PHP-Versie: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `frietonline`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `adminsettings`
--

CREATE TABLE IF NOT EXISTS `adminsettings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `clientLevel` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Gegevens worden uitgevoerd voor tabel `adminsettings`
--

INSERT INTO `adminsettings` (`id`, `clientLevel`) VALUES
(1, 1);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `bezoeker`
--

CREATE TABLE IF NOT EXISTS `bezoeker` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(50) NOT NULL,
  `bezoekdatum` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Gegevens worden uitgevoerd voor tabel `bezoeker`
--

INSERT INTO `bezoeker` (`id`, `ip`, `bezoekdatum`) VALUES
(1, '::1', '2016-05-20 02:53:06');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `bezoekerhit`
--

CREATE TABLE IF NOT EXISTS `bezoekerhit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(50) NOT NULL,
  `bezoekdatum` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Gegevens worden uitgevoerd voor tabel `bezoekerhit`
--

INSERT INTO `bezoekerhit` (`id`, `ip`, `bezoekdatum`) VALUES
(1, '::1', '2016-05-20 02:53:06');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `categorie`
--

CREATE TABLE IF NOT EXISTS `categorie` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `naam` varchar(50) NOT NULL,
  `hoofdcategorieId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `HoofdcategorieId` (`hoofdcategorieId`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Gegevens worden uitgevoerd voor tabel `categorie`
--

INSERT INTO `categorie` (`id`, `naam`, `hoofdcategorieId`) VALUES
(1, 'Broodjes', NULL),
(2, 'Snacks', NULL),
(3, 'Frieten', NULL),
(4, 'Dranken', NULL),
(5, 'Salades', NULL),
(6, 'Sauzen', NULL);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `menuitem`
--

CREATE TABLE IF NOT EXISTS `menuitem` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `naam` varchar(250) NOT NULL,
  `omschrijving` text NOT NULL,
  `fotoPad` varchar(250) NOT NULL,
  `prijs` double NOT NULL,
  `categorieId` int(11) NOT NULL,
  `vlees` tinyint(4) NOT NULL DEFAULT '0',
  `vis` tinyint(4) NOT NULL DEFAULT '0',
  `pikantheid` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `categorieId` (`categorieId`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Gegevens worden uitgevoerd voor tabel `menuitem`
--

INSERT INTO `menuitem` (`id`, `naam`, `omschrijving`, `fotoPad`, `prijs`, `categorieId`, `vlees`, `vis`, `pikantheid`) VALUES
(1, 'Broodje gezond', 'Broodje met kaas, hesp, aardappelsla, tomaat, ei en sla.', '', 3, 1, 1, 0, 0),
(2, 'Broodje boulet', 'Broodje met sla, ei, tomaat, boulet en cocktailsaus.', '', 3.5, 1, 1, 0, 0),
(3, 'Kleine friet', 'Kleine zak friet.', '', 1.8, 3, 0, 0, 0),
(4, 'Gewone friet', 'Gewone zak friet.', '', 2, 3, 0, 1, 0),
(5, 'Grote friet', 'Grote zak friet.', '', 2.2, 3, 0, 0, 0),
(6, 'Familie friet', 'Een zak friet voor de familie (2-3 personen).', '', 3.5, 3, 0, 0, 0),
(7, 'Frikandel', 'Frikandel van mora.', '', 2.3, 2, 1, 0, 0),
(8, 'Boulet', 'Ronde boulet gebakken.', '', 2.3, 2, 1, 0, 0),
(9, 'Playboy', 'Pikante playboy met look.', '', 2.5, 2, 1, 0, 2),
(10, 'Cola (33 cl.)', 'Blikje Cola van 33 cl.', '', 1.8, 4, 0, 0, 0),
(11, 'Fanta (33 cl.)', 'Blikje Fanta van 33 cl.', '', 1.8, 4, 0, 0, 0),
(12, 'Sprite (33 cl.)', 'Blikje Sprite van 33 cl.', '', 1.8, 4, 0, 0, 0);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `tekst`
--

CREATE TABLE IF NOT EXISTS `tekst` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `naam` varchar(150) NOT NULL,
  `pagina` varchar(150) NOT NULL,
  `tekst` text NOT NULL,
  `tekstgrootte` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Gegevens worden uitgevoerd voor tabel `tekst`
--

INSERT INTO `tekst` (`id`, `naam`, `pagina`, `tekst`, `tekstgrootte`) VALUES
(1, 'Home tekst', 'home.php', '<ul>\r\n<li>Welkom bij frietonline!<li>\r\n<li>Bekijk ons aanbod en bestel nu!</li>\r\n<ul>', 195),
(2, 'Over ons tekst', 'overons.php', '<ul>\r\n<li>Ricardo is stoer, Jeroen is ook stoer. What would <strong>you</strong> want more!\r\n </ul>', 100),
(3, 'Contact openingsuren', 'info.php', '<ul>\r\n <li>Maandag - Zaterdag: 10:30 - 17:30</li>\r\n<li>Zondag: gesloten</li>\r\n </ul>', 100),
(4, 'Timer tekst', 'timer.php', 'Beste klant wij zijn momenteel bezig om onze website voor u te verbeteren. Tijd tot de website terug beschikbaar is:', 175);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
